export { default } from './VetListPage';
