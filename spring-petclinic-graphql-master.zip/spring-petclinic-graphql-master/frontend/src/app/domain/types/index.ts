export * from "./query-types-generated";
export * from "./petclinic-types";
