export { default as AddOwnerPage } from "./AddOwnerPage";
export { default as OwnerListPage } from "./OwnerListPage";
export { default as OwnerPage } from "./OwnerPage";
export { default as UpdateOwnerPage } from "./UpdateOwnerPage";
