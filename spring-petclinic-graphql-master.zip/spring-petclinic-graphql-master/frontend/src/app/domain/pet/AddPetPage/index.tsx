export { default } from "./AddPetPage";

