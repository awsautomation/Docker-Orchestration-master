export { default } from "./SpecialtiesPage";
