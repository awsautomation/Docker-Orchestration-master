export { default as SpecialtiesPage } from "./SpecialtiesPage";
