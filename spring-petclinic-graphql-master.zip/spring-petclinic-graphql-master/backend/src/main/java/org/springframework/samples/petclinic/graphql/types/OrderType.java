package org.springframework.samples.petclinic.graphql.types;


/**
 * @author Xiangbin HAN (hanxb2001@163.com)
 *
 */
public enum OrderType {
    ASC,
    DESC
}
