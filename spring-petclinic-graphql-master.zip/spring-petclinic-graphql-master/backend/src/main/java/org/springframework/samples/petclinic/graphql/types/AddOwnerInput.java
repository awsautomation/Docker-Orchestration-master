package org.springframework.samples.petclinic.graphql.types;

/**
 * @author Nils Hartmann (nils@nilshartmann.net)
 */
public class AddOwnerInput extends AbstractOwnerInput {

    @Override
    public String toString() {
        return "AddOwnerInput{} " + super.toString();
    }
}
